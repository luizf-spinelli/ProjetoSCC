-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28-Fev-2018 às 13:46
-- Versão do servidor: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `confeccao`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `IDCLIENTE` int(11) NOT NULL,
  `NOME` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`IDCLIENTE`, `NOME`) VALUES
(1, 'Luiz'),
(2, 'AndrÃ© GPA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_contato`
--

CREATE TABLE `cliente_contato` (
  `IDCLIENTE` int(11) NOT NULL,
  `TEL` varchar(14) DEFAULT NULL,
  `CEL` varchar(14) DEFAULT NULL,
  `EMAIL` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente_contato`
--

INSERT INTO `cliente_contato` (`IDCLIENTE`, `TEL`, `CEL`, `EMAIL`) VALUES
(1, '(13)3665-6959', '(13)99148-4984', 'luiz@fatec.com'),
(2, '(21)3161-4616', '(21)98465-1561', 'andre@gpa.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_endereco`
--

CREATE TABLE `cliente_endereco` (
  `PAIS` varchar(30) DEFAULT NULL,
  `ESTADO` varchar(2) DEFAULT NULL,
  `CIDADE` varchar(30) DEFAULT NULL,
  `BAIRRO` varchar(30) DEFAULT NULL,
  `CEP` varchar(10) DEFAULT NULL,
  `RUA` varchar(50) DEFAULT NULL,
  `COMP` varchar(30) DEFAULT NULL,
  `IDCLIENTE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente_endereco`
--

INSERT INTO `cliente_endereco` (`PAIS`, `ESTADO`, `CIDADE`, `BAIRRO`, `CEP`, `RUA`, `COMP`, `IDCLIENTE`) VALUES
('Brasil', 'SP', 'Santos', 'Centro', '11310444', 'Rua de Santos, 122', 'Bloco C', 1),
('Brasil', 'RJ', 'Rio de Janeiro', 'Centro', '31168148', 'Rua do ComÃ©rcio', '', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_fisico`
--

CREATE TABLE `cliente_fisico` (
  `IDCLIENTE` int(11) NOT NULL,
  `CPF` varchar(14) DEFAULT NULL,
  `RG` varchar(12) DEFAULT NULL,
  `SEXO` char(1) DEFAULT NULL,
  `DTNASCIMENTO` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente_fisico`
--

INSERT INTO `cliente_fisico` (`IDCLIENTE`, `CPF`, `RG`, `SEXO`, `DTNASCIMENTO`) VALUES
(1, '333.333.333-33', '44.444.444-4', 'M', '1993-03-26');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_juridico`
--

CREATE TABLE `cliente_juridico` (
  `IDCLIENTE` int(11) NOT NULL,
  `CNPJ` varchar(18) DEFAULT NULL,
  `RSOCIAL` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente_juridico`
--

INSERT INTO `cliente_juridico` (`IDCLIENTE`, `CNPJ`, `RSOCIAL`) VALUES
(2, '44.444.444/4444-44', 'Grupo PÃ£o de AÃ§Ãºcar');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_medidas`
--

CREATE TABLE `cliente_medidas` (
  `IDCLIENTE` int(11) NOT NULL,
  `OMBROAOMBRO` varchar(10) DEFAULT NULL,
  `OMBRO` varchar(10) DEFAULT NULL,
  `COLARINHO` varchar(10) DEFAULT NULL,
  `CAVASFRENTE` varchar(10) DEFAULT NULL,
  `CENTROFRENTE` varchar(10) DEFAULT NULL,
  `CAVASCOSTA` varchar(10) DEFAULT NULL,
  `BUSTO` varchar(10) DEFAULT NULL,
  `ALTBUSTO` varchar(10) DEFAULT NULL,
  `SEPBUSTO` varchar(10) DEFAULT NULL,
  `CINTURA` varchar(10) DEFAULT NULL,
  `QUADRIL` varchar(10) DEFAULT NULL,
  `ALTQUADRIL` varchar(10) DEFAULT NULL,
  `ALTGANCHOFRENTE` varchar(10) DEFAULT NULL,
  `ALTGANCHOCOSTA` varchar(10) DEFAULT NULL,
  `CINTURAAOJOELHO` varchar(10) DEFAULT NULL,
  `CINTURAAOTORNOZELO` varchar(10) DEFAULT NULL,
  `LARGJOELHO` varchar(10) DEFAULT NULL,
  `BOCACALCA` varchar(10) DEFAULT NULL,
  `CUMPRBRACO` varchar(10) DEFAULT NULL,
  `LARGBRACO` varchar(10) DEFAULT NULL,
  `PUNHO` varchar(10) DEFAULT NULL,
  `ALTMANGATRESQUARTOS` varchar(10) DEFAULT NULL,
  `ALTMANGACURTA` varchar(10) DEFAULT NULL,
  `ALTSAIA` varchar(10) DEFAULT NULL,
  `ALTFRENTE` varchar(10) DEFAULT NULL,
  `ALTCOSTA` varchar(10) DEFAULT NULL,
  `IDMEDIDA` int(11) NOT NULL,
  `OBS` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente_medidas`
--

INSERT INTO `cliente_medidas` (`IDCLIENTE`, `OMBROAOMBRO`, `OMBRO`, `COLARINHO`, `CAVASFRENTE`, `CENTROFRENTE`, `CAVASCOSTA`, `BUSTO`, `ALTBUSTO`, `SEPBUSTO`, `CINTURA`, `QUADRIL`, `ALTQUADRIL`, `ALTGANCHOFRENTE`, `ALTGANCHOCOSTA`, `CINTURAAOJOELHO`, `CINTURAAOTORNOZELO`, `LARGJOELHO`, `BOCACALCA`, `CUMPRBRACO`, `LARGBRACO`, `PUNHO`, `ALTMANGATRESQUARTOS`, `ALTMANGACURTA`, `ALTSAIA`, `ALTFRENTE`, `ALTCOSTA`, `IDMEDIDA`, `OBS`) VALUES
(1, '55.00', '0.00', '0.00', '0.00', '75.35', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '125.23', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', 1, 'Uniforme escolar'),
(2, '0.00', '322.05', '0.00', '0.00', '0.00', '0.00', '48.26', '0.00', '0.00', '66.56', '0.00', '999.99', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '999.99', '0.00', 3, 'Uniforme aÃ§ougue'),
(1, '987.46', '64.09', '85,05', '', '', '', '63,08', '32.55', '321.2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 6, 'Traje Social');

-- --------------------------------------------------------

--
-- Estrutura da tabela `composicao`
--

CREATE TABLE `composicao` (
  `IDSERV` int(11) NOT NULL,
  `IDPEDIDO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `REGISTRO` int(11) NOT NULL,
  `NOME` varchar(45) NOT NULL,
  `FUNCAO` varchar(45) NOT NULL,
  `DTADMISSAO` varchar(10) DEFAULT NULL,
  `DTDEMISSAO` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`REGISTRO`, `NOME`, `FUNCAO`, `DTADMISSAO`, `DTDEMISSAO`) VALUES
(2, 'Maria', 'Costureira', '2017-11-08', '2017-11-10'),
(23, 'Jose', 'Auxiliar', '2017-11-09', ''),
(50, 'JoÃ£o', 'Alfaiate', '2017-11-02', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `kaccessk`
--

CREATE TABLE `kaccessk` (
  `id` int(10) NOT NULL,
  `nome` varchar(25) NOT NULL,
  `usuario` varchar(25) NOT NULL,
  `senha` varchar(25) NOT NULL,
  `ACESSO` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `kaccessk`
--

INSERT INTO `kaccessk` (`id`, `nome`, `usuario`, `senha`, `ACESSO`) VALUES
(1, 'Administrador', 'adm', '123', '2'),
(2, 'Luiz', 'lspinelli', '321', '2'),
(3, 'FuncionÃ¡rio habilitado', 'Teste0', '123', '1'),
(4, 'Funcionario desabilitado', 'Teste1', '123', '0');

-- --------------------------------------------------------

--
-- Estrutura da tabela `maquina`
--

CREATE TABLE `maquina` (
  `IDMAQ` int(11) NOT NULL,
  `TIPO` varchar(30) DEFAULT NULL,
  `MODELO` varchar(50) DEFAULT NULL,
  `DTUMANUTENCAO` varchar(10) DEFAULT NULL,
  `DTPMANUTENCAO` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `maquina`
--

INSERT INTO `maquina` (`IDMAQ`, `TIPO`, `MODELO`, `DTUMANUTENCAO`, `DTPMANUTENCAO`) VALUES
(1, 'Bordadeira', 'MK-3055-J', '2017-11-03', '2017-11-01'),
(2, 'Costuradora', 'JF-2017-5', '2018-01-17', '2018-01-01');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `IDPEDIDO` int(11) NOT NULL,
  `TIPO` varchar(30) DEFAULT NULL,
  `DTPAGAMENTO` varchar(10) DEFAULT NULL,
  `VALOR` varchar(10) DEFAULT NULL,
  `STATS` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido`
--

CREATE TABLE `pedido` (
  `IDPEDIDO` int(11) NOT NULL,
  `IDCLIENTE` int(11) NOT NULL,
  `DTINICIO` varchar(10) DEFAULT NULL,
  `DTSOLICITACAO` varchar(10) DEFAULT NULL,
  `QTDE` int(11) DEFAULT '1',
  `IDSERV` int(11) DEFAULT NULL,
  `PRAZO` varchar(10) NOT NULL,
  `OBSV` varchar(100) DEFAULT NULL,
  `STATUS` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ped_fun`
--

CREATE TABLE `ped_fun` (
  `IDPEDIDO` int(11) NOT NULL,
  `REGISTRO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servico`
--

CREATE TABLE `servico` (
  `IDSERV` int(11) NOT NULL,
  `TIPO` varchar(20) NOT NULL,
  `VALOR_BASE` varchar(8) DEFAULT NULL,
  `DURACAO` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `servico`
--

INSERT INTO `servico` (`IDSERV`, `TIPO`, `VALOR_BASE`, `DURACAO`) VALUES
(1, 'Costura', '50,00', '7'),
(2, 'ConfecÃ§Ã£o', '85,00', '14'),
(3, 'Conserto', '25,00', '7'),
(4, 'Bordado', '40,00', '7'),
(50, 'Treinamento', '140,00', '3');

-- --------------------------------------------------------

--
-- Estrutura da tabela `serv_maq`
--

CREATE TABLE `serv_maq` (
  `IDSERVICO` int(11) NOT NULL,
  `IDMAQ` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`IDCLIENTE`);

--
-- Indexes for table `cliente_contato`
--
ALTER TABLE `cliente_contato`
  ADD PRIMARY KEY (`IDCLIENTE`),
  ADD UNIQUE KEY `TEL` (`TEL`),
  ADD UNIQUE KEY `CEL` (`CEL`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`);

--
-- Indexes for table `cliente_endereco`
--
ALTER TABLE `cliente_endereco`
  ADD PRIMARY KEY (`IDCLIENTE`);

--
-- Indexes for table `cliente_fisico`
--
ALTER TABLE `cliente_fisico`
  ADD PRIMARY KEY (`IDCLIENTE`),
  ADD UNIQUE KEY `CPF` (`CPF`),
  ADD UNIQUE KEY `RG` (`RG`);

--
-- Indexes for table `cliente_juridico`
--
ALTER TABLE `cliente_juridico`
  ADD PRIMARY KEY (`IDCLIENTE`),
  ADD UNIQUE KEY `CNPJ` (`CNPJ`);

--
-- Indexes for table `cliente_medidas`
--
ALTER TABLE `cliente_medidas`
  ADD PRIMARY KEY (`IDMEDIDA`),
  ADD KEY `fk_CLIENTE_MEDIDAS_CLIENTE1` (`IDCLIENTE`);

--
-- Indexes for table `composicao`
--
ALTER TABLE `composicao`
  ADD PRIMARY KEY (`IDSERV`,`IDPEDIDO`),
  ADD KEY `fk_COMPOSICAO_PEDIDO1_idx` (`IDPEDIDO`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`REGISTRO`);

--
-- Indexes for table `kaccessk`
--
ALTER TABLE `kaccessk`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indexes for table `maquina`
--
ALTER TABLE `maquina`
  ADD PRIMARY KEY (`IDMAQ`);

--
-- Indexes for table `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`IDPEDIDO`);

--
-- Indexes for table `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`IDPEDIDO`),
  ADD KEY `fk_PEDIDO_CLIENTE1` (`IDCLIENTE`);

--
-- Indexes for table `ped_fun`
--
ALTER TABLE `ped_fun`
  ADD PRIMARY KEY (`IDPEDIDO`,`REGISTRO`),
  ADD KEY `fk_ALOCACAO_FUNCIONARIO1_idx` (`REGISTRO`);

--
-- Indexes for table `servico`
--
ALTER TABLE `servico`
  ADD PRIMARY KEY (`IDSERV`);

--
-- Indexes for table `serv_maq`
--
ALTER TABLE `serv_maq`
  ADD PRIMARY KEY (`IDMAQ`,`IDSERVICO`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cliente_medidas`
--
ALTER TABLE `cliente_medidas`
  MODIFY `IDMEDIDA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cliente_contato`
--
ALTER TABLE `cliente_contato`
  ADD CONSTRAINT `fk_TELEFONE_CLIENTE1` FOREIGN KEY (`IDCLIENTE`) REFERENCES `cliente` (`IDCLIENTE`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `cliente_fisico`
--
ALTER TABLE `cliente_fisico`
  ADD CONSTRAINT `fk_CLIENTE_FISICO_CLIENTE1` FOREIGN KEY (`IDCLIENTE`) REFERENCES `cliente` (`IDCLIENTE`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `cliente_juridico`
--
ALTER TABLE `cliente_juridico`
  ADD CONSTRAINT `fk_CLIENTE_JURIDICO_CLIENTE1` FOREIGN KEY (`IDCLIENTE`) REFERENCES `cliente` (`IDCLIENTE`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `cliente_medidas`
--
ALTER TABLE `cliente_medidas`
  ADD CONSTRAINT `fk_CLIENTE_MEDIDAS_CLIENTE1` FOREIGN KEY (`IDCLIENTE`) REFERENCES `cliente` (`IDCLIENTE`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `composicao`
--
ALTER TABLE `composicao`
  ADD CONSTRAINT `fk_COMPOSICAO_PEDIDO1` FOREIGN KEY (`IDPEDIDO`) REFERENCES `pedido` (`IDPEDIDO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_COMPOSICAO_SERVICO1` FOREIGN KEY (`IDSERV`) REFERENCES `servico` (`IDSERV`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `fk_PEDIDO_CLIENTE1` FOREIGN KEY (`IDCLIENTE`) REFERENCES `cliente` (`IDCLIENTE`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `ped_fun`
--
ALTER TABLE `ped_fun`
  ADD CONSTRAINT `fk_ALOCACAO_FUNCIONARIO1` FOREIGN KEY (`REGISTRO`) REFERENCES `funcionario` (`REGISTRO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ALOCACAO_PEDIDO1` FOREIGN KEY (`IDPEDIDO`) REFERENCES `pedido` (`IDPEDIDO`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
